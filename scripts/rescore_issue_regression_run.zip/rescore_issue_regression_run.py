#!/usr/bin/env python3
"""Audit-rescore an existing issue run after scorer-marker refinements."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from datetime import date
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RUNNER_PATH = ROOT / "scripts" / "run_gpt56_sol_issue_regression.py"
BANK_PATH = ROOT / "tests" / "gpt56_sol_issue_regression_bank.jsonl"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_runner():
    spec = importlib.util.spec_from_file_location("issue_runner", RUNNER_PATH)
    if spec is None or spec.loader is None:
        raise SystemExit("cannot load issue runner")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("summary")
    parser.add_argument("--output")
    parser.add_argument("--reason", default="generalized progress vocabulary and substantive-output scorer refinement")
    args = parser.parse_args()
    runner = load_runner()
    source_path = Path(args.summary).expanduser().resolve()
    source = json.loads(source_path.read_text(encoding="utf-8"))
    bank_rows = runner.read_jsonl(BANK_PATH)
    bank = {str(row["case_id"]): row for row in bank_rows}
    source_ids = [str(value) for value in source.get("selected_case_ids") or []]
    if not source_ids:
        raise SystemExit("source summary lacks selected_case_ids")
    artifacts = dict(source.get("artifacts") or {})
    scored_path = Path(str(artifacts["scored"]))
    scored = runner.read_jsonl(scored_path)
    order = {case_id: index for index, case_id in enumerate(source_ids)}
    scored.sort(key=lambda item: (order[str(item["case_id"])], int(item["repeat"]), int(item["turn"])))
    previous: dict[tuple[str, int], str] = {}
    rescored: list[dict[str, object]] = []
    for item in scored:
        case_id = str(item["case_id"])
        repeat = int(item["repeat"])
        turn = int(item["turn"])
        row = bank.get(case_id)
        if row is None:
            raise SystemExit(f"case absent from current bank: {case_id}")
        spec = list(row["turns"])[turn - 1]
        if str(item.get("raw_prompt") or "") != str(spec["user"]):
            raise SystemExit(f"raw prompt changed for {case_id} turn {turn}; model rerun required")
        key = (case_id, repeat)
        answer = str(item.get("response") or "")
        prior_source = str(item.get("error_source") or "model_response")
        execution_source = (
            prior_source
            if prior_source in runner.RESUMABLE_ERROR_SOURCES or prior_source == "provider_policy_block"
            else "model_response"
        )
        score = runner.score_answer(
            row=row,
            turn_spec=spec,
            answer=answer,
            previous_answer=previous.get(key, ""),
            execution_source=execution_source,
            parsed=bool(item.get("parsed_json")),
        )
        updated = dict(item)
        updated.update(score)
        rescored.append(updated)
        previous[key] = answer

    if args.output:
        output = Path(args.output).expanduser().resolve()
    else:
        stem = source_path.name.removesuffix(".summary.json")
        output = source_path.with_name(stem + "_rescored.summary.json")
    output.parent.mkdir(parents=True, exist_ok=True)
    rescored_path = output.with_name(output.name.removesuffix(".summary.json") + ".scored.jsonl")
    report_path = output.with_name(output.name.removesuffix(".summary.json") + ".md")
    runner.write_jsonl(rescored_path, rescored)
    summary_bits = runner.summarize(rescored, len(source_ids))
    new_artifacts = dict(artifacts)
    new_artifacts.update(scored=str(rescored_path), summary=str(output), report=str(report_path))
    updated_summary = dict(source)
    updated_summary.update({
        "date": date.today().isoformat(),
        "bank": str(BANK_PATH),
        "bank_sha256": sha256(BANK_PATH),
        "runner_file": str(RUNNER_PATH),
        "runner_sha256": sha256(RUNNER_PATH),
        "execution_runner_sha256": source.get("runner_sha256"),
        "rescore_source_summary": str(source_path),
        "rescore_reason": args.reason,
        "artifacts": new_artifacts,
        **summary_bits,
    })
    runner.write_json(output, updated_summary)
    runner.write_report(report_path, summary_bits, updated_summary, rescored)
    print(output)
    print(json.dumps(summary_bits, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
