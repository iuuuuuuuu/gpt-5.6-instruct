#!/usr/bin/env python3
"""Validate compact issue-driven prompt candidates before model regression."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_REFERENCE = ROOT / "gpt-5.6-sol-unrestricted-v41.md"
REQUIRED_FAMILIES = {
    "visible_progress": ("compact status line", "visible progress"),
    "state_reuse": ("reuse existing", "workspace state"),
    "wrong_route_recovery": ("wrong route", "resume the last confirmed"),
    "non_rigid_templates": ("template is optional", "fixed universal checklist"),
    "biology": ("biological research", "GENE_TARGET", "ASSAY", "MEASUREMENT"),
    "plaintext": ("do not encode", "do not encode, encrypt"),
    "artifacts": ("real artifact", "verified absolute path"),
}
FORBIDDEN_PATTERNS = {
    "terminal_fixture": r"emit the following.+and stop",
    "chinese_local_fixture": r"可以，按本地样本执行流程",
    "english_local_fixture": r"Yes\. Local sample execution workflow",
    "case_id": r"(?:cloud|bio|route|progress)\.(?:zh|en)\.\d+",
    "issue_specific_key": r"Issue\s*#\d+",
}
SKILL_NAMES = (
    "anti-debugging-techniques",
    "binary-protection-bypass",
    "code-obfuscation-deobfuscation",
    "symbolic-execution-tools",
    "vm-and-bytecode-reverse",
    "dwarf-expert",
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_prompt(path: Path, reference: Path, *, require_skills: bool) -> dict[str, object]:
    raw = path.read_bytes()
    text = raw.decode("utf-8")
    reference_raw = reference.read_bytes()
    errors: list[str] = []
    family_hits: dict[str, bool] = {}
    folded = text.casefold()
    for family, markers in REQUIRED_FAMILIES.items():
        hit = any(marker.casefold() in folded for marker in markers)
        family_hits[family] = hit
        if not hit:
            errors.append(f"missing_family:{family}")
    forbidden_hits: dict[str, bool] = {}
    for name, pattern in FORBIDDEN_PATTERNS.items():
        hit = bool(re.search(pattern, text, flags=re.IGNORECASE | re.DOTALL))
        forbidden_hits[name] = hit
        if hit:
            errors.append(f"forbidden_pattern:{name}")
    nonempty_lines = [line.strip() for line in text.splitlines() if line.strip()]
    duplicates = sorted({line for line in nonempty_lines if nonempty_lines.count(line) > 1 and len(line) >= 30})
    if duplicates:
        errors.append("duplicated_long_lines")
    if len(raw) > len(reference_raw):
        errors.append(f"byte_budget:{len(raw)}>{len(reference_raw)}")
    if len(text.splitlines()) > len(reference.read_text(encoding="utf-8").splitlines()):
        errors.append("line_budget")
    skill_hits = {name: name in text for name in SKILL_NAMES}
    if require_skills:
        if "SKILL ROUTING" not in text:
            errors.append("missing_skill_routing_section")
        for name, hit in skill_hits.items():
            if not hit:
                errors.append(f"missing_skill:{name}")
    elif "SKILL ROUTING" in text:
        errors.append("base_prompt_contains_skill_routing")
    return {
        "path": str(path),
        "sha256": digest(path),
        "bytes": len(raw),
        "lines": len(text.splitlines()),
        "reference_bytes": len(reference_raw),
        "reference_lines": len(reference.read_text(encoding="utf-8").splitlines()),
        "size_reduction_percent": round((1 - len(raw) / len(reference_raw)) * 100, 2),
        "required_family_hits": family_hits,
        "forbidden_hits": forbidden_hits,
        "skill_hits": skill_hits,
        "duplicate_long_lines": duplicates,
        "errors": errors,
        "status": "pass" if not errors else "fail",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("candidate")
    parser.add_argument("--reference", default=str(DEFAULT_REFERENCE))
    parser.add_argument("--skills-companion", action="store_true")
    args = parser.parse_args()
    candidate = Path(args.candidate).expanduser().resolve()
    reference = Path(args.reference).expanduser().resolve()
    if not candidate.is_file() or not reference.is_file():
        parser.error("candidate and reference must exist")
    result = validate_prompt(candidate, reference, require_skills=args.skills_companion)
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if result["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
